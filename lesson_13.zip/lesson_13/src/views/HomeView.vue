<template>
<div class="school">
  <div class="school__wrapper">
    <div class="school__block">
      <p class="school__text">
        Welcome to our school homepage!
      </p>
      <p class="school__text">
        The pupil can chose lessons and teachers him/herself in our school
      </p>
      <p class="school__text">
        Login to use full features
      </p>
    </div>
  </div>
</div>
</template>

<script>
// @ is an alias to /src
export default {
  name: "HomeView",
};
</script>
