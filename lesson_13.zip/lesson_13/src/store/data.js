export const lessonsList = [
    {
        id:1,
        title: 'Ukrainian language',
    },
    {
        id:2,
        title: 'Mathematics',
    },
    {
        id:3,
        title: 'Physics',
    },
    {
        id:4,
        title: 'Chemistry',
    },
    {
        id:5,
        title: 'Biology',
    },
    {
        id:6,
        title: 'Geography',
    },
    {
        id:7,
        title: 'History',
    },
    {
        id:8,
        title: 'English language',
    },
    {
        id:9,
        title: 'Literature',
    },
    {
        id:10,
        title: 'Music',
    }
]

export const teachersList = [
    {
        id:1,
        name: 'Ivan Vasylenko',
    },
    {
        id:2,
        name: 'Vasyl Korobenko',
    },
    {
        id:3,
        name: 'Petro Petrovenko',
    },
    {
        id:4,
        name: 'Kyrylo Poroshenko',
    },
    {
        id:5,
        name: 'Maria Ivanenko',
    },
    {
        id:6,
        name: 'Anna Turenko',
    },
    {
        id:7,
        name: 'Kateryna Stelmakhova',
    },
    {
        id:8,
        name: 'Oleg Ryzhkyn',
    },
    {
        id:9,
        name: 'Olga Kovalenko',
    },
    {
        id:10,
        name: 'Oskar Lidström',
    },
    {
        id:11,
        name: 'Athena Korosh',
    }
]